package com.boosteroid.checker.ui.proxy

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.boosteroid.checker.data.prefs.SettingsPrefs
import com.boosteroid.checker.databinding.FragmentProxyBinding
import com.boosteroid.checker.network.ProxyManager

class ProxyFragment : Fragment() {
    private var _binding: FragmentProxyBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SettingsPrefs
    private val proxyManager = ProxyManager()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?) =
        FragmentProxyBinding.inflate(inflater, container, false).also { _binding = it }.root
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = SettingsPrefs(requireContext())
        binding.etProxyList.setText(prefs.proxyList); updateCount()
        binding.btnSaveProxies.setOnClickListener { prefs.proxyList = binding.etProxyList.text.toString(); updateCount() }
        binding.btnClearProxies.setOnClickListener { binding.etProxyList.setText(""); prefs.proxyList = ""; updateCount() }
        binding.tvProxyFormat.text = "Format: host:port  or  host:port:user:pass\nSupports HTTP/HTTPS/SOCKS"
    }
    private fun updateCount() {
        val parsed = prefs.proxyList.lines().mapNotNull { proxyManager.parseProxyLine(it) }
        binding.tvProxyCount.text = "Proxies loaded: ${parsed.size}"
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
