package com.boosteroid.checker.ui.results

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.boosteroid.checker.data.db.AppDatabase
import com.boosteroid.checker.data.db.ResultEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ResultsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).resultDao()
    val results = dao.getAllFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun clearAll() = viewModelScope.launch { dao.deleteAll() }
    suspend fun getByStatus(status: String): List<ResultEntity> = dao.getByStatus(status)
    suspend fun getAll(): List<ResultEntity> = dao.getAll()
}
