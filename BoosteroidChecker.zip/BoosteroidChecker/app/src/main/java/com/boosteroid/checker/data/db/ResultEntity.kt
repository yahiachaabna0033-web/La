package com.boosteroid.checker.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "results")
data class ResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val password: String,
    val status: String,
    val planType: String?,
    val autoRenew: String?,
    val paymentMethod: String?,
    val timestamp: Long = System.currentTimeMillis()
)
