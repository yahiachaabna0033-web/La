package com.boosteroid.checker.ui.results

import android.graphics.Color
import android.view.*
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.boosteroid.checker.R
import com.boosteroid.checker.data.db.ResultEntity

class ResultsAdapter : ListAdapter<ResultEntity, ResultsAdapter.VH>(DIFF) {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvEmail: TextView = view.findViewById(R.id.tvEmail)
        val tvPassword: TextView = view.findViewById(R.id.tvPassword)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
        val tvDetails: TextView = view.findViewById(R.id.tvDetails)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_result, parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.tvEmail.text = item.email; holder.tvPassword.text = item.password; holder.tvStatus.text = item.status
        holder.tvStatus.setTextColor(when (item.status) { "PAID" -> Color.parseColor("#4CAF50"); "FREE" -> Color.parseColor("#FFC107"); "FAIL" -> Color.parseColor("#F44336"); else -> Color.parseColor("#9E9E9E") })
        holder.tvDetails.text = buildString { item.planType?.let { append("Plan: $it | ") }; item.autoRenew?.let { append("AutoRenew: $it | ") }; item.paymentMethod?.let { append("Pay: $it") } }
    }
    companion object { val DIFF = object : DiffUtil.ItemCallback<ResultEntity>() { override fun areItemsTheSame(a: ResultEntity, b: ResultEntity) = a.id == b.id; override fun areContentsTheSame(a: ResultEntity, b: ResultEntity) = a == b } }
}
