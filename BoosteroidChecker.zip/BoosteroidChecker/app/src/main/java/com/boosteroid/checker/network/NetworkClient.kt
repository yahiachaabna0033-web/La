package com.boosteroid.checker.network

import okhttp3.Authenticator
import okhttp3.Credentials
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClient {
    fun buildApiService(timeoutSeconds: Long = 30L, proxy: ProxyEntry? = null, proxyManager: ProxyManager? = null): ApiService {
        val builder = OkHttpClient.Builder()
            .connectTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .writeTimeout(timeoutSeconds, TimeUnit.SECONDS)
        val activeProxy = proxy ?: proxyManager?.next()
        activeProxy?.let { pe ->
            builder.proxy(proxyManager?.toOkHttpProxy(pe) ?: ProxyManager().toOkHttpProxy(pe))
            if (pe.username != null && pe.password != null) {
                builder.proxyAuthenticator(Authenticator { _, response ->
                    response.request.newBuilder().header("Proxy-Authorization", Credentials.basic(pe.username, pe.password)).build()
                })
            }
        }
        return Retrofit.Builder().baseUrl(ApiService.BASE_URL).client(builder.build())
            .addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)
    }
}
