package com.boosteroid.checker.network

import java.net.InetSocketAddress
import java.net.Proxy

enum class ProxyType { HTTP, HTTPS, SOCKS4, SOCKS5 }

data class ProxyEntry(val host: String, val port: Int, val type: ProxyType = ProxyType.HTTP,
    val username: String? = null, val password: String? = null)

class ProxyManager {
    private val proxies = mutableListOf<ProxyEntry>()
    private var index = 0

    fun setProxies(list: List<ProxyEntry>) { proxies.clear(); proxies.addAll(list); index = 0 }
    fun next(): ProxyEntry? { if (proxies.isEmpty()) return null; return proxies[index++ % proxies.size] }
    fun toOkHttpProxy(entry: ProxyEntry): Proxy {
        val type = when (entry.type) { ProxyType.SOCKS4, ProxyType.SOCKS5 -> Proxy.Type.SOCKS; else -> Proxy.Type.HTTP }
        return Proxy(type, InetSocketAddress(entry.host, entry.port))
    }
    fun parseProxyLine(line: String): ProxyEntry? = try {
        val p = line.trim().split(":")
        when (p.size) { 2 -> ProxyEntry(p[0], p[1].toInt()); 4 -> ProxyEntry(p[0], p[1].toInt(), ProxyType.HTTP, p[2], p[3]); else -> null }
    } catch (e: Exception) { null }
    fun size() = proxies.size
    fun isEmpty() = proxies.isEmpty()
}
