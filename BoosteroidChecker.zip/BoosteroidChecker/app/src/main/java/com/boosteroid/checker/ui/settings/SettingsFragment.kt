package com.boosteroid.checker.ui.settings

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.boosteroid.checker.data.prefs.SettingsPrefs
import com.boosteroid.checker.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SettingsPrefs
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?) =
        FragmentSettingsBinding.inflate(inflater, container, false).also { _binding = it }.root
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = SettingsPrefs(requireContext())
        binding.etTimeout.setText(prefs.timeoutSeconds.toString()); binding.etThreads.setText(prefs.threads.toString())
        binding.etRetries.setText(prefs.retries.toString()); binding.switchUseProxy.isChecked = prefs.useProxy
        binding.switchRotateProxy.isChecked = prefs.rotateProxies; binding.switchTelegram.isChecked = prefs.telegramEnabled
        binding.etBotToken.setText(prefs.telegramBotToken); binding.etChatId.setText(prefs.telegramChatId)
        binding.btnSaveSettings.setOnClickListener {
            prefs.timeoutSeconds = binding.etTimeout.text.toString().toIntOrNull() ?: 30
            prefs.threads = binding.etThreads.text.toString().toIntOrNull() ?: 5
            prefs.retries = binding.etRetries.text.toString().toIntOrNull() ?: 2
            prefs.useProxy = binding.switchUseProxy.isChecked; prefs.rotateProxies = binding.switchRotateProxy.isChecked
            prefs.telegramEnabled = binding.switchTelegram.isChecked; prefs.telegramBotToken = binding.etBotToken.text.toString()
            prefs.telegramChatId = binding.etChatId.text.toString()
            binding.tvSavedMsg.visibility = View.VISIBLE
            binding.tvSavedMsg.postDelayed({ binding.tvSavedMsg.visibility = View.GONE }, 2000)
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
