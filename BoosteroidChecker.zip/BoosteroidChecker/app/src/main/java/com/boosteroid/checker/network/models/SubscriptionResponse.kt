package com.boosteroid.checker.network.models

import com.google.gson.annotations.SerializedName

data class SubscriptionResponse(@SerializedName("data") val data: List<SubscriptionData>?)
data class SubscriptionData(
    @SerializedName("subscriptionId")    val subscriptionId: String?,
    @SerializedName("title")             val title: String?,
    @SerializedName("isAutoRenewal")     val isAutoRenewal: Boolean?,
    @SerializedName("isActive")          val isActive: Boolean?,
    @SerializedName("paymentSystemTitle") val paymentSystemTitle: String?
)
