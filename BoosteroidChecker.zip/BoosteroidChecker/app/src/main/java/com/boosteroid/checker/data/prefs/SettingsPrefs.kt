package com.boosteroid.checker.data.prefs

import android.content.Context

class SettingsPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("checker_settings", Context.MODE_PRIVATE)
    var timeoutSeconds: Int get() = prefs.getInt("timeout", 30); set(v) = prefs.edit().putInt("timeout", v).apply()
    var threads: Int get() = prefs.getInt("threads", 5); set(v) = prefs.edit().putInt("threads", v).apply()
    var retries: Int get() = prefs.getInt("retries", 2); set(v) = prefs.edit().putInt("retries", v).apply()
    var useProxy: Boolean get() = prefs.getBoolean("use_proxy", false); set(v) = prefs.edit().putBoolean("use_proxy", v).apply()
    var rotateProxies: Boolean get() = prefs.getBoolean("rotate_proxies", true); set(v) = prefs.edit().putBoolean("rotate_proxies", v).apply()
    var proxyList: String get() = prefs.getString("proxy_list", "") ?: ""; set(v) = prefs.edit().putString("proxy_list", v).apply()
    var telegramEnabled: Boolean get() = prefs.getBoolean("telegram_enabled", false); set(v) = prefs.edit().putBoolean("telegram_enabled", v).apply()
    var telegramBotToken: String get() = prefs.getString("telegram_bot_token", "") ?: ""; set(v) = prefs.edit().putString("telegram_bot_token", v).apply()
    var telegramChatId: String get() = prefs.getString("telegram_chat_id", "") ?: ""; set(v) = prefs.edit().putString("telegram_chat_id", v).apply()
}
