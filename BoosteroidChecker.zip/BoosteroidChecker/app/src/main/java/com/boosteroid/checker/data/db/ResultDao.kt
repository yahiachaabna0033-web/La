package com.boosteroid.checker.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ResultDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(result: ResultEntity): Long

    @Query("SELECT * FROM results ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<ResultEntity>>

    @Query("SELECT * FROM results WHERE status = :status ORDER BY timestamp DESC")
    suspend fun getByStatus(status: String): List<ResultEntity>

    @Query("SELECT * FROM results ORDER BY timestamp DESC")
    suspend fun getAll(): List<ResultEntity>

    @Query("DELETE FROM results")
    suspend fun deleteAll()

    @Query("DELETE FROM results WHERE status = :status")
    suspend fun deleteByStatus(status: String)

    @Query("SELECT COUNT(*) FROM results WHERE status = 'PAID'")
    fun paidCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM results WHERE status = 'FREE'")
    fun freeCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM results")
    fun totalCountFlow(): Flow<Int>
}
