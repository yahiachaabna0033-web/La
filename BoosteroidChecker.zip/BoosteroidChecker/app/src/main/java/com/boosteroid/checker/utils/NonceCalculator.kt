package com.boosteroid.checker.utils

import java.security.MessageDigest

object NonceCalculator {
    fun calculate(input: String): Int {
        val stringBytes = input.toByteArray(Charsets.UTF_8)
        val dataBytes = ByteArray(4 + stringBytes.size)
        System.arraycopy(stringBytes, 0, dataBytes, 4, stringBytes.size)
        val sha512 = MessageDigest.getInstance("SHA-512")
        for (counter in 0 until 0x7FFFFFFF) {
            dataBytes[0] = ((counter shr 24) and 0xFF).toByte()
            dataBytes[1] = ((counter shr 16) and 0xFF).toByte()
            dataBytes[2] = ((counter shr 8) and 0xFF).toByte()
            dataBytes[3] = (counter and 0xFF).toByte()
            sha512.reset()
            val hash = sha512.digest(dataBytes)
            if (hash[0] == 0.toByte() && hash[1] == 0.toByte()) return counter
        }
        return -1
    }
}
