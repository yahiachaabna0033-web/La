package com.boosteroid.checker.ui.checker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.boosteroid.checker.data.db.AppDatabase
import com.boosteroid.checker.data.prefs.SettingsPrefs
import com.boosteroid.checker.data.repository.CheckerRepository
import com.boosteroid.checker.network.ProxyManager

class CheckerViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = SettingsPrefs(app)
    private val proxyManager = ProxyManager()
    val repository = CheckerRepository(AppDatabase.get(app).resultDao(), prefs, proxyManager)
    val logFlow = repository.logFlow
    val statsFlow = repository.statsFlow
    fun startChecking(combos: List<String>) { repository.startChecking(combos, viewModelScope) }
    fun stopChecking() = repository.stopChecking()
    fun isRunning() = repository.isRunning()
}
