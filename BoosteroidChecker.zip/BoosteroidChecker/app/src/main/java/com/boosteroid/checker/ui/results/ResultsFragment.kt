package com.boosteroid.checker.ui.results

import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.boosteroid.checker.databinding.FragmentResultsBinding
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.io.File

class ResultsFragment : Fragment() {
    private var _binding: FragmentResultsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ResultsViewModel by viewModels()
    private val adapter = ResultsAdapter()
    private var filterStatus = "ALL"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?) =
        FragmentResultsBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvResults.layoutManager = LinearLayoutManager(requireContext())
        binding.rvResults.adapter = adapter
        val opts = listOf("ALL", "PAID", "FREE", "FAIL", "ERROR")
        binding.spinnerFilter.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, opts).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        binding.spinnerFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { filterStatus = opts[pos]; applyFilter() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        viewModel.results.onEach { applyFilter() }.launchIn(viewLifecycleOwner.lifecycleScope)
        binding.btnClearResults.setOnClickListener { viewModel.clearAll() }
        binding.btnExport.setOnClickListener {
            lifecycleScope.launch {
                val items = if (filterStatus == "ALL") viewModel.getAll() else viewModel.getByStatus(filterStatus)
                val file = File(requireContext().getExternalFilesDir(null), "results_$filterStatus.txt")
                file.writeText(items.joinToString("\n") { r -> buildString { append("${r.email}:${r.password} [${r.status}]"); r.planType?.let { append(" | Plan: $it") }; r.autoRenew?.let { append(" | AutoRenew: $it") }; r.paymentMethod?.let { append(" | Pay: $it") } } })
                binding.tvExportPath.text = "Saved: ${file.absolutePath}"
            }
        }
    }

    private fun applyFilter() {
        val all = viewModel.results.value
        val filtered = if (filterStatus == "ALL") all else all.filter { it.status == filterStatus }
        adapter.submitList(filtered); binding.tvResultCount.text = "Showing ${filtered.size} / ${all.size}"
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
