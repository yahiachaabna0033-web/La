package com.boosteroid.checker

import android.app.Application

class App : Application() {
    override fun onCreate() { super.onCreate() }
}
