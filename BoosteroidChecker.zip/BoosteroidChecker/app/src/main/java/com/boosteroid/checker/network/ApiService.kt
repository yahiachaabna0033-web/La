package com.boosteroid.checker.network

import com.boosteroid.checker.network.models.LoginRequest
import com.boosteroid.checker.network.models.LoginResponse
import com.boosteroid.checker.network.models.SubscriptionResponse
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @POST("api/v1/auth/login")
    suspend fun login(
        @Header("Accept") accept: String = "application/json",
        @Header("Accept-Encoding") encoding: String = "gzip",
        @Header("Accept-Language") language: String = "en-US",
        @Header("Connection") connection: String = "Keep-Alive",
        @Header("Content-Type") contentType: String = "application/json; charset=UTF-8",
        @Header("Cookie") cookie: String = "boosteroid_entrypoint_source=1; boosteroid_entrypoint_page=1",
        @Header("Device-Info") deviceInfo: String = DEVICE_INFO,
        @Header("Device-Name") deviceName: String = DEVICE_NAME,
        @Header("Device-Uniq-Id") deviceUniqId: String = "",
        @Header("Host") host: String = "cloud.boosteroid.com",
        @Header("User-Agent") userAgent: String = USER_AGENT,
        @Header("X-Nonce-17") nonce: String,
        @Body body: LoginRequest
    ): Response<LoginResponse>

    @GET("api/v1/payments/subscriptions")
    suspend fun getSubscriptions(
        @Query("active") active: Boolean = true,
        @Header("Accept") accept: String = "application/json",
        @Header("Accept-Encoding") encoding: String = "gzip",
        @Header("Accept-Language") language: String = "en-US",
        @Header("Authorization") authorization: String,
        @Header("Authorization-Data") authData: String,
        @Header("Connection") connection: String = "Keep-Alive",
        @Header("Content-Type") contentType: String = "application/json",
        @Header("Device-Info") deviceInfo: String = DEVICE_INFO,
        @Header("Device-Name") deviceName: String = DEVICE_NAME,
        @Header("Device-Uniq-Id") deviceUniqId: String = "",
        @Header("Host") host: String = "cloud.boosteroid.com",
        @Header("User-Agent") userAgent: String = USER_AGENT
    ): Response<SubscriptionResponse>

    companion object {
        const val BASE_URL = "https://cloud.boosteroid.com/"
        const val DEVICE_INFO = "{\"brand\":\"google\",\"chip\":\"GenuineIntel\",\"device\":\"emu64xa\",\"hardware\":\"ranchu\",\"manufacturer\":\"Google\",\"model\":\"sdk_gphone64_x86_64\",\"name\":\"UE1A.230829.036.A4\",\"product\":\"sdk_gphone64_x86_64\"}"
        const val DEVICE_NAME = "emu64xa sdk_gphone64_x86_64 34"
        const val USER_AGENT = "BoosteroidAndroidClient v.1.6.29; Android 14; sdk_gphone64_x86_64"
    }
}
