package com.boosteroid.checker.network.models

import com.google.gson.annotations.SerializedName

data class LoginResponse(@SerializedName("data") val data: LoginData?)
data class LoginData(
    @SerializedName("user") val user: UserData?,
    @SerializedName("access_token") val accessToken: String?
)
data class UserData(@SerializedName("email") val email: String?)
