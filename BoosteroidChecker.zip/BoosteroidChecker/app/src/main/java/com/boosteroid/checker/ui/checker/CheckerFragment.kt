package com.boosteroid.checker.ui.checker

import android.graphics.Color
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.boosteroid.checker.data.repository.LogType
import com.boosteroid.checker.databinding.FragmentCheckerBinding
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class CheckerFragment : Fragment() {
    private var _binding: FragmentCheckerBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CheckerViewModel by viewModels()

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        val content = requireContext().contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return@registerForActivityResult
        binding.etComboList.setText(content)
        binding.tvComboCount.text = "Lines: ${content.lines().count { it.contains(":") }}"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?) =
        FragmentCheckerBinding.inflate(inflater, container, false).also { _binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnLoadFile.setOnClickListener { filePicker.launch("text/*") }
        binding.btnStart.setOnClickListener {
            if (viewModel.isRunning()) { viewModel.stopChecking(); binding.btnStart.text = "▶ Start" }
            else {
                val combos = binding.etComboList.text.toString().lines().filter { it.contains(":") }
                if (combos.isEmpty()) return@setOnClickListener
                binding.tvLog.text = ""
                viewModel.startChecking(combos)
                binding.btnStart.text = "⏹ Stop"
            }
        }
        binding.btnClearLog.setOnClickListener { binding.tvLog.text = "" }

        viewModel.logFlow.onEach { entry ->
            val color = when (entry.type) {
                LogType.SUCCESS -> Color.parseColor("#4CAF50"); LogType.FAIL -> Color.parseColor("#F44336")
                LogType.ERROR -> Color.parseColor("#FF9800"); LogType.INFO -> Color.parseColor("#90CAF9")
            }
            val line = "[${android.text.format.DateFormat.format("HH:mm:ss", entry.timestamp)}] ${entry.message}\n"
            val span = SpannableString(line).apply { setSpan(ForegroundColorSpan(color), 0, line.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
            requireActivity().runOnUiThread {
                binding.tvLog.append(span)
                (binding.tvLog.parent as? ScrollView)?.post { (binding.tvLog.parent as ScrollView).fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }.launchIn(viewLifecycleOwner.lifecycleScope)

        viewModel.statsFlow.onEach { s ->
            requireActivity().runOnUiThread {
                binding.progressBar.max = s.total; binding.progressBar.progress = s.checked
                binding.tvStats.text = "Total: ${s.total} | Checked: ${s.checked} | ✅ Paid: ${s.paid} | 🟡 Free: ${s.free} | ❌ Fail: ${s.failed}"
                if (s.checked >= s.total && s.total > 0) binding.btnStart.text = "▶ Start"
            }
        }.launchIn(viewLifecycleOwner.lifecycleScope)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
