package com.boosteroid.checker.network.models

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("client_id")    val clientId: Int = 6,
    @SerializedName("client_secret") val clientSecret: String = "CDYb8AnfFEeU3p4Rd1A3oGonxMJMe3TdWJwDWSsy",
    @SerializedName("email")        val email: String,
    @SerializedName("password")     val password: String
)
