# Boosteroid Checker — Android App

## Quick Start
1. Open in Android Studio
2. Sync Gradle
3. Build & Run

## Structure
- `checker/` — Main checking UI + ViewModel
- `results/` — Results viewer with filter & export
- `settings/` — Thread/timeout/proxy/telegram config
- `proxy/` — Proxy list manager

## Notes
- NonceCalculator runs on Dispatchers.Default (CPU-heavy)
- Room DB auto-creates on first launch
- Export saves to: `/Android/data/com.boosteroid.checker/files/`
- Proxy format: `ip:port` or `ip:port:user:pass`
- Telegram: create bot via @BotFather, get chat_id via @userinfobot
